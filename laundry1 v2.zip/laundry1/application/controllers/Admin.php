<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        date_default_timezone_set('Asia/Jakarta');

        $this->load->model('m_data');
        $this->load->library('session');
        $this->load->library('form_validation');

        //cek session yang login,
        // jika session status tidak sama dengan session telah_login, berarti pelanggan belum login
        // maka halaman akan di alihkan kembali ke halaman login.
        if($this->session->userdata('status')!="telah_login"){
            redirect(base_url().'login?alert=belum_login');
        }
    }

    public function index()
    {
        $this->load->view('admin/dashboard');
        //$this->load->view('admin/v_index');
        //$this->load->view('admin/v_footer');
    }

    public function keluar()
    {
        $this->session->sess_destroy();
        redirect('login?alert=logout');
    }

    // CRUD Pelanggan
    public function pelanggan()
    {
        $data['pelanggan'] = $this->m_data->get_data('tb_pelanggan')->result();
        $this->load->view('admin/pelanggan',$data);
    }

    public function pelanggan_tambah()
    {
        $this->load->view('admin/f_tambah_pelanggan');
    }

    public function pelanggan_aksi()
    {
        //validasi input
        $this->form_validation->set_rules('id_pelanggan','id_pelanggan','required');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('alamat','alamat','required');
        $this->form_validation->set_rules('jenis_kelamin','jenis_kelamin','required');
        $this->form_validation->set_rules('tlp','tlp','required');
        //chek kondisi validasi
        if($this->form_validation->run() != false){
            //ambil input dariform
            $id_pelanggan = $this->input->post('id_pelanggan');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $jenis_kelamin = $this->input->post('jenis_kelamin');
            $tlp = $this->input->post('tlp');
            // data yang di simpan ke DB
            $data = array(
                'id_pelanggan' => $id_pelanggan,
                'nama' => $nama,
                'alamat' => $alamat,
                'jenis_kelamin' => $jenis_kelamin,
                'tlp' => $tlp   
            );
            // perintah untuk menambahkan data ke DB melalui model m_data
            $this->m_data->insert_data($data,'tb_pelanggan');
            // halaman di arahkan ke halaman admin pelanggan
            redirect(base_url().'admin/pelanggan');
            
        }else{
            // jika proses input tidak berhasil akan di arahkan ke halaman tambah pelanggan
            $this->load->view('admin/f_tambah_pelanggan');
            
        }
    }

    public function pelanggan_edit($id_pelanggan) // mengambil data dari button edit
    {
        // kondisi data yang akan di ambil dari database
        $where = array(
            'id_pelanggan' => $id_pelanggan
        );

        $data['pelanggan'] = $this->m_data->edit_data($where,'tb_pelanggan')->result(); // perintah ambil data dari tabel pelanggan
        $this->load->view('admin/f_pelanggan_edit',$data); // ambil data UI form edit pelanggan
    }

    public function pelanggan_update()
    {
        //validasi update
        $this->form_validation->set_rules('id_pelanggan','id_pelanggan','required');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('alamat','alamat','required');
        $this->form_validation->set_rules('jenis_kelamin','jenis_kelamin','required');
        $this->form_validation->set_rules('tlp','tlp','required');
        // chek kondisi validasi
        if($this->form_validation->run() != false){
            // ambil dara fari form edit pelanggan
            $id_pelanggan = $this->input->post('id_pelanggan');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $jenis_kelamin = $this->input->post('jenis_kelamin');
            $tlp = $this->input->post('tlp');
            // untuk kondisi data yang akan di update
            $where = array(
                'id_pelanggan' => $id_pelanggan
            );
            // data yang akan di update
            $data = array(
                'nama' => $nama,
                'alamat' => $alamat,
                'jenis_kelamin' => $jenis_kelamin,
                'tlp' => $tlp
            );
            // perintah update data ke database
            $this->m_data->update_data($where, $data,'tb_pelanggan');
            // di arahkan ke halaman admin pelanggan
            redirect(base_url().'admin/pelanggan');
            
        }else{
            // jika validasi update tidak berhasil 
            $id_pelanggan = $this->input->post('id_pelanggan');
            // kondisi data yang akan di ambil
            $where = array(
                'id_pelanggan' => $id_pelanggan
            );
            // perintah untuk mengambil data dari database
            $data['pelanggan'] = $this->m_data->edit_data($where,'tb_pelanggan')->result();
            // halaman di alihkan ke form edit pelanggan
            $this->load->view('admin/f_pelanggan_edit',$data);
        }
    }

    public function pelanggan_hapus($id_pelanggan)
    {
        $where = array(
            'id_pelanggan' => $id_pelanggan
        );

        $this->m_data->delete_data($where,'tb_pelanggan');

        redirect(base_url().'admin/pelanggan');
    }
    // END CRUD pelanggan

    // CRUD Outlet
    public function outlet()
    {
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $this->load->view('admin/outlet',$data);
    }

    public function outlet_tambah()
    {
        $this->load->view('admin/f_tambah_outlet');
    }

    public function outlet_aksi()
    {
        //validasi input
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('alamat','alamat','required');
        $this->form_validation->set_rules('tlp','tlp','required');

        //chek kondisi validasi
        if($this->form_validation->run() != false){
            //ambil input dariform
            $id_outlet = $this->input->post('id_outlet');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $tlp = $this->input->post('tlp');

            // data yang di simpan ke DB
            $data = array(
                'id_outlet' => $id_outlet,
                'nama' => $nama,
                'alamat' => $alamat,
                'tlp' => $tlp   
            );
            // perintah untuk menambahkan data ke DB melalui model m_data
            $this->m_data->insert_data($data,'tb_outlet');
            // halaman di arahkan ke halaman admin outlet
            redirect(base_url().'admin/outlet');
            
        }else{
            // jika proses input tidak berhasil akan di arahkan ke halaman tambah Outlet
            $this->load->view('admin/f_tambah_outlet');
            
        }
    }

    public function outlet_edit($id_outlet) // mengambil data dari button edit
    {
        // kondisi data yang akan di ambil dari database
        $where = array(
            'id_outlet' => $id_outlet
        );

        $data['outlet'] = $this->m_data->edit_data($where,'tb_outlet')->result(); // perintah ambil data dari tabel pelanggan
        $this->load->view('admin/f_outlet_edit',$data); // ambil data UI form edit Outlet
    }

    public function outlet_update()
    {
        //validasi update
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('alamat','alamat','required');
        $this->form_validation->set_rules('tlp','tlp','required');

        // chek kondisi validasi
        if($this->form_validation->run() != false){
            // ambil dara fari form edit Outlet
            $id_outlet = $this->input->post('id_outlet');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $tlp = $this->input->post('tlp');
            // untuk kondisi data yang akan di update
            $where = array(
                'id_outlet' => $id_outlet
            );
            // data yang akan di update
            $data = array(
                'nama' => $nama,
                'alamat' => $alamat,
                'tlp' => $tlp
            );
            // perintah update data ke database
            $this->m_data->update_data($where, $data,'tb_outlet');
            // di arahkan ke halaman admin pelanggan
            redirect(base_url().'admin/outlet');
            
        }else{
            // jika validasi update tidak berhasil 
            $id_outlet = $this->input->post('id_outlet');

            // kondisi data yang akan di ambil
            $where = array(
                'id_outlet' => $id_outlet
            );
            // perintah untuk mengambil data dari database
            $data['outlet'] = $this->m_data->edit_data($where,'tb_outlet')->result();
            // halaman di alihkan ke form edit pelanggan
            $this->load->view('admin/f_outlet_edit',$data);
        }
    }

    public function outlet_hapus($id_outlet)
    {
        $where = array(
            'id_outlet' => $id_outlet
        );

        $this->m_data->delete_data($where,'tb_outlet');

        redirect(base_url().'admin/outlet');
    }
    // END CRUD Outlet

    // CRUD Paket
    public function paket()
    
    {
        $data['paket'] = $this->m_data->get_data('tb_paket')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $this->load->view('admin/paket',$data);
    }

    public function paket_tambah()
    {
        $this->load->view('admin/f_tambah_paket');
    }

    public function paket_aksi()
    {
        //validasi input
        $this->form_validation->set_rules('id_paket','id_paket','required');
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('jenis','jenis','required');
        $this->form_validation->set_rules('nama_paket','nama_paket','required');
        $this->form_validation->set_rules('harga','harga','required');
        //chek kondisi validasi
        if($this->form_validation->run() != false){
            //ambil input dariform
            $id_paket = $this->input->post('id_paket');
            $id_outlet = $this->input->post('id_outlet');
            $jenis = $this->input->post('jenis');
            $nama_paket = $this->input->post('nama_paket');
            $harga = $this->input->post('harga');
            // data yang di simpan ke DB
            $data = array(
                'id_paket' => $id_paket,
                'id_outlet' => $id_outlet,
                'jenis' => $jenis,
                'nama_paket' => $nama_paket,
                'harga' => $harga   
            );
            // perintah untuk menambahkan data ke DB melalui model m_data
            $this->m_data->insert_data($data,'tb_paket');
            // halaman di arahkan ke halaman admin paket
            redirect(base_url().'admin/paket');
            
        }else{
            // jika proses input tidak berhasil akan di arahkan ke halaman tambah paket
            $this->load->view('admin/f_tambah_paket');
            
        }
    }

    public function paket_edit($id_paket) // mengambil data dari button edit
    {
        // kondisi data yang akan di ambil dari database
        $where = array(
            'id_paket' => $id_paket
        );

        $data['paket'] = $this->m_data->edit_data($where,'tb_paket')->result(); // perintah ambil data dari tabel paket
        $this->load->view('admin/f_paket_edit',$data); // ambil data UI form edit paket
    }

    public function paket_update()
    {
        //validasi update
        $this->form_validation->set_rules('id_paket','id_paket','required');
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('jenis','jenis','required');
        $this->form_validation->set_rules('nama_paket','nama_paket','required');
        $this->form_validation->set_rules('harga','harga','required');
        // chek kondisi validasi
        if($this->form_validation->run() != false){
            // ambil data dari form edit paket
            $id_paket = $this->input->post('id_paket');
            $id_outlet = $this->input->post('id_outlet');
            $jenis = $this->input->post('jenis');
            $nama_paket = $this->input->post('nama_paket');
            $harga = $this->input->post('harga');
            // untuk kondisi data yang akan di update
            $where = array(
                'id_paket' => $id_paket
            );
            // data yang akan di update
            $data = array(
                'id_paket' => $id_paket,
                'id_outlet' => $id_outlet,
                'jenis' => $jenis,
                'nama_paket' => $nama_paket,
                'harga' => $harga
            );
            // perintah update data ke database
            $this->m_data->update_data($where, $data,'tb_paket');
            // di arahkan ke halaman admin paket
            redirect(base_url().'admin/paket');
            
        }else{
            // jika validasi update tidak berhasil 
            $id_paket = $this->input->post('id_paket');
            // kondisi data yang akan di ambil
            $where = array(
                'id_paket' => $id_paket
            );
            // perintah untuk mengambil data dari database
            $data['paket'] = $this->m_data->edit_data($where,'tb_paket')->result();
            // halaman di alihkan ke form edit paket
            $this->load->view('admin/f_paket_edit',$data);
        }
    }

    public function paket_hapus($id_paket)
    {
        $where = array(
            'id_paket' => $id_paket
        );

        $this->m_data->delete_data($where,'tb_paket');

        redirect(base_url().'admin/paket');
    }
    // END CRUD Paket

    // CRUD Transaksi
    public function transaksi()
    {
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['pelanggan'] = $this->m_data->get_data('tb_pelanggan')->result();
        $this->load->view('admin/transaksi',$data);
    }

    public function transaksi_tambah()
    {
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['pelanggan'] = $this->m_data->get_data('tb_pelanggan')->result();        
        $this->load->view('admin/f_tambah_transaksi');
    }

    public function transaksi_aksi()
    {
        //validasi input
        $this->form_validation->set_rules('id_transaksi', 'id_transaksi', 'required');
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required');
        $this->form_validation->set_rules('kode_invoice', 'kode_invoice', 'required');
        $this->form_validation->set_rules('id_pelanggan', 'id_pelanggan', 'required');
        $this->form_validation->set_rules('tgl', 'tgl', 'required');
        $this->form_validation->set_rules('status', 'status', 'required');
        $this->form_validation->set_rules('dibayar', 'dibayar', 'required');
        $this->form_validation->set_rules('id_user', 'id_user', 'required');
        //check kondisi validasi
        if($this->form_validation->run() != false){
            //ambil input dariform
            $id_transaksi = $this->input->post('id_transaksi');
            $id_outlet = $this->input->post('id_outlet');
            $kode_invoice = $this->input->post('kode_invoice');
            $id_pelanggan = $this->input->post('id_pelanggan');
            $tgl = $this->input->post('tgl');
            $status = $this->input->post('status');
            $dibayar = $this->input->post('dibayar');
            $id_user = $this->input->post('id_user');
            // data yang di simpan ke DB
            $data = array(
                'id_transaksi' => $id_transaksi,
                'id_outlet' => $id_outlet,
                'kode_invoice' => $kode_invoice,
                'id_pelanggan' => $id_pelanggan,
                'tgl' => $tgl,
                'status' => $status,
                'dibayar' => $dibayar,
                'id_user' => $id_user
            );
            // perintah untuk menambahkan data ke DB melalui model m_data
            $this->m_data->insert_data($data,'tb_transaksi');
            // halaman di arahkan ke halaman admin transaksi
            redirect(base_url().'admin/transaksi');
            
        }else{
            // jika proses input tidak berhasil akan di arahkan ke halaman tambah transaksi
            $this->load->view('admin/f_tambah_transaksi');
            
        }
    }

    public function transaksi_edit($id_transaksi) // mengambil data dari button edit
    {
        // kondisi data yang akan di ambil dari database
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['pelanggan'] = $this->m_data->get_data('tb_pelanggan')->result();
        $where = array(
            'id_transaksi' => $id_transaksi
        );

        $data['transaksi'] = $this->m_data->edit_data($where,'tb_transaksi')->result(); // perintah ambil data dari tabel transaksi
        $this->load->view('admin/f_transaksi_edit',$data); // ambil data UI form edit transaksi
    }

    public function transaksi_update()
    {
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['pelanggan'] = $this->m_data->get_data('tb_pelanggan')->result();

        //validasi update
        $this->form_validation->set_rules('id_transaksi', 'id_transaksi', 'required');
        $this->form_validation->set_rules('id_outlet', 'id_outlet', 'required');
        $this->form_validation->set_rules('kode_invoice', 'kode_invoice', 'required');
        $this->form_validation->set_rules('id_pelanggan', 'id_pelanggan', 'required');
        $this->form_validation->set_rules('status', 'status', 'required');
        $this->form_validation->set_rules('dibayar', 'dibayar', 'required');
        // check kondisi validasi
        if($this->form_validation->run() != false){
            // ambil data dari form edit transaksi
            $id_transaksi = $this->input->post('id_transaksi');
            $id_outlet = $this->input->post('id_outlet');
            $kode_invoice = $this->input->post('kode_invoice');
            $id_pelanggan = $this->input->post('id_pelanggan');
            $status = $this->input->post('status');
            $dibayar = $this->input->post('dibayar');
            // untuk kondisi data yang akan di update
            $where = array(
                'id_transaksi' => $id_transaksi
            );
            // data yang akan di update
            $data = array(
                'id_transaksi' => $id_transaksi,
                'id_outlet' => $id_outlet,
                'kode_invoice' => $kode_invoice,
                'id_pelanggan' => $id_pelanggan,
                'status' => $status,
                'dibayar' => $dibayar
            );
            // perintah update data ke database
            $this->m_data->update_data($where, $data,'tb_transaksi');
            // di arahkan ke halaman admin transaksi
            redirect(base_url().'admin/transaksi');
            
        }else{
            // jika validasi update tidak berhasil 
            $id_transaksi = $this->input->post('id_transaksi');
            // kondisi data yang akan di ambil
            $where = array(
                'id_transaksi' => $id_transaksi
            );
            // perintah untuk mengambil data dari database
            $data['transaksi'] = $this->m_data->edit_data($where,'tb_transaksi')->result();
            // halaman di alihkan ke form edit transaksi
            $this->load->view('admin/f_transaksi_edit',$data);
        }
    }
    // END CRUD Transaksi

    // CRUD user
    public function user()
    {
        $data['user'] = $this->m_data->get_data('tb_user')->result();
        $this->load->view('admin/user',$data);
    }

    public function user_tambah()
    {
        $this->load->view('admin/f_tambah_user');
    }

    public function user_aksi()
    {
        //validasi input
$this->form_validation->set_rules('id_user','id_user','required');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('username','username','required');
        $this->form_validation->set_rules('password','password','required');
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('role','role','required');
        //check kondisi validasi
        if($this->form_validation->run() != false){
            //ambil input dariform
            $id_user = $this->input->post('id_user');
            $nama = $this->input->post('nama');
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $id_outlet = $this->input->post('id_outlet');
            $role = $this->input->post('role');
            // data yang di simpan ke DB
            $data = array(
                'id_user' => $id_user,
                'nama' => $nama,
                'username' =>$username,
                'password' =>md5($password),
                'id_outlet' => $id_outlet,
                'role' => $role   
            );
            // perintah untuk menambahkan data ke DB melalui model m_data
            $this->m_data->insert_data($data,'tb_user');
            // halaman di arahkan ke halaman admin user
            redirect(base_url().'admin/user');
            
        }else{
            // jika proses input tidak berhasil akan di arahkan ke halaman tambah user
            $this->load->view('admin/f_tambah_user');
            
        }
        
        public function user_edit($id_user) // mengambil data dari button edit
    {
        // kondisi data yang akan di ambil dari database
        $data['user'] = $this->m_data->get_data('tb_user')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $where = array(
            'id_user' => $id_user
        );

        $data['user'] = $this->m_data->edit_data($where,'tb_user')->result(); // perintah ambil data dari tabel transaksi
        $this->load->view('admin/f_user_edit',$data); // ambil data UI form edit transaksi
    }

    public function user_update()
    {
        $data['user'] = $this->m_data->get_data('tb_user')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();

        //validasi update
        $this->form_validation->set_rules('id_user','id_user','required');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('username','username','required');
        $this->form_validation->set_rules('password','password','required');
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('role','role','required');
        // check kondisi validasi
        if($this->form_validation->run() != false){
            // ambil data dari form edit transaksi
            $id_user = $this->input->post('id_user');
            $nama = $this->input->post('nama');
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $id_outlet = $this->input->post('id_outlet');
            $role = $this->input->post('role');
            // untuk kondisi data yang akan di update
            $where = array(
                'id_user' => $id_user
            );
            // data yang akan di update
            $data = array(
                'id_user' => $id_user,
                'nama' => $nama,
                'username' =>$username,
                'password' =>md5($password),
                'id_outlet' => $id_outlet,
                'role' => $role
            );
            // perintah update data ke database
            $this->m_data->update_data($where, $data,'tb_user');
            // di arahkan ke halaman admin transaksi
            redirect(base_url().'admin/user');
            
        }else{
            // jika validasi update tidak berhasil 
            $id_user = $this->input->post('id_user');
            // kondisi data yang akan di ambil
            $where = array(
                'id_user' => $id_user
            );
            // perintah untuk mengambil data dari database
            $data['user'] = $this->m_data->edit_data($where,'tb_user')->result();
            // halaman di alihkan ke form edit transaksi
            $this->load->view('admin/f_user_edit',$data);
        }
        
        public function user_hapus($id_user)
      {
        $where = array(
            'id_user' => $id_user
        );

        $this->m_data->delete_data($where,'tb_user');

        redirect(base_url().'admin/user');
    }
    }


    // fungsi PDFView
    public function pdfview_pelanggan()
    {
        // panggil library yang kita buat sebelumnya yang bernama pdfgenerator
        $this->load->library('pdfgenerator');
        
        // title dari pdf
        $this->data['title_pdf'] = 'Laporan Penjualan Toko Kita';
        
        // filename dari pdf ketika didownload
        $file_pdf = 'laporan_pelanggan';
        // setting paper
        $paper = 'A4';
        //orientasi paper potrait / landscape
        $orientation = "portrait";

        $data['pelanggan'] = $this->m_data->get_data('tb_pelanggan')->result();
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['paket'] = $this->m_data->get_data('tb_paket')->result();
        $html = $this->load->view('admin/laporan_pelanggan',$data, true);      
        
        // run dompdf
        $this->pdfgenerator->generate($html, $file_pdf,$paper,$orientation);
        
    }
}