<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Owner extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        date_default_timezone_set('Asia/Jakarta');

        $this->load->model('m_data');
        $this->load->library('session');
        $this->load->library('form_validation');

        //cek session yang login,
        // jika session status tidak sama dengan session telah_login, berarti pelanggan belum login
        // maka halaman akan di alihkan kembali ke halaman login.
        if($this->session->userdata('status')!="telah_login"){
            redirect(base_url().'login?alert=belum_login');
        }
    }

    public function index()
    {
        $this->load->view('owner/dashboard');
        //$this->load->view('owner/v_index');
        //$this->load->view('owner/v_footer');
    }

    public function keluar()
    {
        $this->session->sess_destroy();
        redirect('login?alert=logout');
    }

    // fungsi PDFView
    public function pdfview_pelanggan()
    {
        // panggil library yang kita buat sebelumnya yang bernama pdfgenerator
        $this->load->library('pdfgenerator');
        
        // title dari pdf
        $this->data['title_pdf'] = 'Laporan Penjualan Toko Kita';
        
        // filename dari pdf ketika didownload
        $file_pdf = 'laporan_pelanggan';
        // setting paper
        $paper = 'A4';
        //orientasi paper potrait / landscape
        $orientation = "portrait";

        $data['pelanggan'] = $this->m_data->get_data('tb_pelanggan')->result();
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $data['paket'] = $this->m_data->get_data('tb_paket')->result();
        $html = $this->load->view('owner/laporan_pelanggan',$data, true);      
        
        // run dompdf
        $this->pdfgenerator->generate($html, $file_pdf,$paper,$orientation);
    }


}