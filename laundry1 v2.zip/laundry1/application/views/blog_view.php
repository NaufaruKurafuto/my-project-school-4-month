<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title><?php echo $title;?></title>
        <!-- load bootstrap css file -->
        <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css');?>" rel="stysheet">
    </head>
    <body>
        <h1><?php echo $content;?></h1>
        <!-- load bootstrap js file -->

        <script src="<? echo base_url('assets/bootstrap/js/bootstrap.min.js');?>"></script>
    </body>
</html>