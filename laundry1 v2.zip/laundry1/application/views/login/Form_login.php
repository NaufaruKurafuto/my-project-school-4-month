<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Koneksi Bootstrap CSS -->
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css');?>"
rel="stylesheet">

    <title>Form Login | Laundry</title> 
  </head>
  <body>
  <?php
    if(isset($_GET['alert'])){
        if($_GET['alert']=="gagal"){
            echo "<div class='alert alert-danger font-weight-bold text-center'>Maaf! Email & Password Salah.</div>";
        }if($_GET['alert']=="belum_login"){
            echo "<div class='alert alert-danger font-weight-bold text-center'>Anda Harus Login Terlebih Dulu!</div>";
        }else if($_GET['alert']=="logout"){
            echo "<div class='alert alert-success font-weight-bold text-center'>Anda Telah Logout!</div>";
        }
    }
    ?>

  <div class="card position-absolute top-50 start-50 translate-middle" style="width: 30rem;">
        <div class="card-body">
            <h3 class="card-title text-center" >SIGN IN</h3>
            <form action="<?php echo base_url().'login/ceklogin' ?> " method="post">
              <label class="form-label">Email</label>
              <input type="text" class="form-control" id="inputEmail4" name="email" placeholder="Masukan Email">
              <label class="form-label">Password</label>
              <input type="password" class="form-control" id="inputEmail4" name="password" placeholder="Masukan Password">
              <br/>
              <input class="btn btn-primary" type="submit" value="Submit">
        
            </form>
        </div>
</div>

<!-- Bootstrap -->
  <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js');?>"></script>
  
<!-- iCheck -->
</body>
</html>